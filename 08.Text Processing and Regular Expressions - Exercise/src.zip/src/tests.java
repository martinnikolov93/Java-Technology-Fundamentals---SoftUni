public class tests {
    public static void main(String[] args) {
        String someString = "Martin";

        System.out.println(someString.lastIndexOf('r'));

        char symbol = someString.charAt(3);
        char a = 'a' + 3;

        System.out.printf("%c",symbol + 3);


    }
}
